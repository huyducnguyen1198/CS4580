## Install the requirements with the following command:

```
pip install -r requirements.txt
```

## Usage

```commandline
python form.py
```